plugins {
    id("cloudstream.plugin")
}

cloudstream {
    language = "tr"
    authors = listOf("sen")
}
